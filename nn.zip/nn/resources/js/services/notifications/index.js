// import store from '../../Pages/store';
// //import SnackbarUtils from '../SnackbarUtils';
// import { notify } from '../../utils/SnackbarUtils';
// let user = store.getState().global.current_user;

// let audio = new Audio('uploads/beep.mp3');
// //audio.autoplay = true;
// var channel = Echo.channel('notificationChannel_' + user.id);

// channel.listen('.TestEvent', function (data) {
//     notify(data.message)
//     SnackbarUtils.notification(data.message, {
//         anchorOrigin: {
//             vertical: 'bottom',
//             horizontal: 'right',
//         },
//     });
//   //  showNotification(data);

// });






// const showNotification = (data) => {
//     // audio.play();
//     //     //if (!document.hidden) {
//     SnackbarUtils.notification(data.message, {
//         anchorOrigin: {
//             vertical: 'bottom',
//             horizontal: 'right',
//         },
//     });
//     ///}


//     //     //  audio.play();
//     //     const title = `${data.message}`;
//     //     new Notification(title);

//     //     // }

// };
