import { Button, makeStyles } from '@material-ui/core';
import { useTranslation } from 'react-i18next';
import { useEffect } from 'react';
import { useFormikContext } from 'formik';
import React from 'react';
import { mainColor } from '../../config/constants';
const useStyles = makeStyles((theme) => ({
    SubmitBtn: {
        backgroundColor:mainColor,
        color: 'white',
        borderRadius: 30,
        outline: 'none',
        fontSize: '12px',
        width: '10%',
        textTransform: 'none',
        '&:hover': {
            backgroundColor:'green',
        },
    },

}));
const SubmitButton = ({ ...props }) => {
    const { t } = useTranslation();
    const classes = useStyles();
    const { isSubmitting, status } = useFormikContext();
    React.useEffect(
        () => {
            //alert(isSubmitting)

        }, [isSubmitting])
    return (
        <Button
            color="primary"
            className={classes.SubmitBtn}
            disabled={isSubmitting}
            type="submit"
            style={{
                float:'rigth'
            }}
        >
            {/* {isSubmitting ? 'Loading' : status.edit ? t('update')  : t('create')} */}

            {isSubmitting ? t('loading') : status.edit ? t('update') : t('create')}



        </Button>
    )
}

export default SubmitButton;