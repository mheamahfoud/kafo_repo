import React, { useEffect, useState } from 'react';
import { Formik } from 'formik';
import { makeStyles, Dialog, DialogActions, DialogContent, DialogContentText, DialogTitle } from '@material-ui/core';
import DonorForm from './DonorForm';
import { UpdateDonor, GetDonor } from '../../../../api/userManagment/donor';
import * as Yup from 'yup';
import { useTranslation } from 'react-i18next';
import SubmitButton from '../../../buttons/submitButton1';
import CancelButton from '../../../buttons/CancelButton';
import { useSnackbar } from "notistack";
import { phoneRegExp } from '../../../../config/constants';
const useStyles = makeStyles((theme) => ({
    tittle: {
        padding: '0px 5px',
        width: 'fit-content',
        color: '#fff',
        backgroundColor: theme.palette.primary.main,
    },
    dialog: {
        position: 'absolute',
        top: 50
    }
}));
export default function EditDonor({ open, data, ...props }) {
    const { t } = useTranslation();
    const { enqueueSnackbar } = useSnackbar();
    const [currentUpdated, setCurrentUpdated] = useState({});
    const DonorSchema = Yup.object().shape({
        mobile: Yup.string().matches(phoneRegExp, t('phone_valid')).nullable(),
        full_name: Yup.string().required(t('required')).nullable(),
        secret_name: Yup.string().required(t('required')).nullable(),
     //   email: Yup.string().email(t('valid_email')).required(t('required')).nullable(),
        email: Yup.string().email(t('valid_email')).nullable(),

    });
    useEffect(() => {
        if (data != null) {
            GetDonor({ 'id': data.id }).then(
                (res) => {
                    console.log(res.data)
                    setCurrentUpdated(res.data)
                }
            )
        }

    }, [data])


    //EditDonor
    const classes = useStyles();

    const handleClose = () => {
        props.onClose();
    };
    return (
        <Dialog
            {...props}
            open={open}
            fullWidth
             classes={{
                paper: classes.dialog
            }}
            disableBackdropClick
            maxWidth={'md'}
            aria-labelledby="form-dialog-title"
        >
            <DialogTitle className={classes.tittle} id="form-dialog-title">
                {t('update_object', { dynamicValue: t('provider') })}
            </DialogTitle>
            <Formik
                enableReinitialize={true}
                validateOnChange={true}
                validationSchema={DonorSchema}
                initialValues={{ ...currentUpdated, medias: [] }}
                initialStatus={{ edit: true }}
                onSubmit={async (values) => {
                    values['email']=!values['email'] ?undefined :values['email'];
                    values['mobile']=!values['mobile'] ?undefined :values['mobile'];
                    UpdateDonor(data.id, values).then((result) => {
                        if (result.success) {
                            enqueueSnackbar(t('updated_successfully'), {
                                variant: 'success',
                                anchorOrigin: {
                                    vertical: 'bottom',
                                    horizontal: 'center',
                                },
                            });
                            props.onClose()
                            props.setUpdateRow(result.data)
                        } else {
                            enqueueSnackbar(result.error_description, {
                                variant: 'error',
                                anchorOrigin: {
                                    vertical: 'bottom',
                                    horizontal: 'center',
                                },
                            });
                        }
                    });
                }}
            >
                {({ setFieldValue, ...props }) => (
                    <form
                        onSubmit={(e) => {

                            e.preventDefault();
                            props.isValid
                                ? props.handleSubmit(e)
                                : Object.keys(
                                    DonorSchema.fields,
                                ).map((field) =>
                                    props.setFieldTouched(field, true),
                                ) &&
                                Object.keys(props.errors).map((item) => {
                                    // enqueueSnackbar(t(item)  + ' ' + t('required'), {
                                    //     variant: 'error',
                                    //     anchorOrigin: {
                                    //         vertical: 'bottom',
                                    //         horizontal: 'center',
                                    //     },
                                    // });
                                });
                        }}
                        style={{ width: '100%' }}
                        autoComplete="off"
                    >

                        <DialogContent>
                            <DialogContentText></DialogContentText>
                            {<DonorForm image_url={data.image_url} />}
                        </DialogContent>
                        <DialogActions>
                            <CancelButton handleClose={handleClose} />
                            <SubmitButton />

                        </DialogActions>

                    </form>
                )}
            </Formik>

        </Dialog >)
}
