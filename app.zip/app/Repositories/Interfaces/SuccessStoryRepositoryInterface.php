<?php

namespace App\Repositories\Interfaces;

interface SuccessStoryRepositoryInterface extends EloquentRepositoryInterface {


 
}