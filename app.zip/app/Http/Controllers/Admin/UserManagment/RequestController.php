<?php


namespace App\Http\Controllers\Admin\UserManagment;

use App\Models\User;
use App\Http\Responses\Response;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use App\Components\Core\Utilities\Helpers;
use App\Models\Donor;
use App\Models\RequestWallet;
use Spatie\Permission\Models\Role;
use App\Http\Resources\AdminResouces;
use App\Http\Resources\Admin\RequestResouces;
use Lang;
use App\Models\Wallet;
use Carbon\Carbon;
class RequestController extends Controller
{
   /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
public function index(Request $request)
    {
        $lang=$request->cookie('current_language');
        //
        if (Auth::guard('api')->check()) {
        
            $rowsPerPage = ($request->get('rowsPerPage') > 0) ? $request->get('rowsPerPage') : 0;
            $sort_by = $request->get('sort_by');
            $descending = $request->get('descending');
    
            if ($descending == 'false') {
                $orderby = 'asc';
            } elseif ($descending == 'true') {
                $orderby = 'desc';
            } elseif ($descending == '') {
                $orderby = 'desc';
                $sort_by = 'id';
            }

            $query = RequestWallet::with(['donor' => function ($q) {
                $q->with(['user'=> function ($q1) {
                    $q1->orderBy('full_name', 'asc');}]) ;
                } ]);
      
            $requests = $query->get();;
            $data=[
                'data' => RequestResouces::collection($requests),
                'total' => count($requests),
            ];
            return Response::respondSuccess($data);

          //  return Response::respondSuccess($Admins);
        }
        else{
            return Response::respondErrorAuthorize(__('site.unauthenticate',[],$lang));
        }
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function acceptRequest(Request $request)
    {
        $lang=$request->cookie('current_language');

        
        if(isset($request->receipt_image))
        {
            if(count($request->receipt_image)==0){
                if($lang=='en')
                   return Response::respondErrorValidation('Receipt Image is Required');
                else{
                    return Response::respondErrorValidation('صورة الوصل اجبارية');
                }
            }
        }
        if (Auth::guard('api')->check()){
       

            try {
                DB::beginTransaction();
                $request_one = RequestWallet::find($request->id);
                $request_one->status='accepted';
                $request_one->update();
                $donor=Donor::find($request_one->donor_id);
                Wallet::charge($request_one->amount, $donor->wallet_id);
                $this->addMedias($request->receipt_image,$donor , 'receipt_image' );
                DB::commit();
                $message = Lang::get('site.success_added',[],$lang);
                return Response::respondSuccess($request_one);
            }
            catch (Exception $e) {
                DB::rollBack();
                return Response::respondError($e);
            }
        }
        else
        return Response::respondErrorAuthorize(__('site.unauthenticate',[],$lang));
    
    }


    public function rejectRequest(Request $request)
    {
        $lang=$request->cookie('current_language');
        if (Auth::guard('api')->check()){
       

            try {
                DB::beginTransaction();
                $request_one = RequestWallet::find($request->id);
                $request_one->status='rejected';
                $request_one->update();
                DB::commit();
                $message = Lang::get('site.success_added',[],$lang);
                return Response::respondSuccess($request_one);

            }
            catch (Exception $e) {
                DB::rollBack();
                return Response::respondError($e);
            }
        }
        else
        return Response::respondErrorAuthorize(__('site.unauthenticate',[],$lang));
    
    }
    
    public function chargeWallet(Request $request)
    {
        $lang=$request->cookie('current_language');
        if (Auth::guard('api')->check()){
       
            $validate = validator($request->all(), [
                'amount' => 'required',
                'donor_id' => 'required',
              
            ],
            [
                'required'  => 'The :attribute field is required.',
                 
                ]
            );

            if ($validate->fails()) {
                return Response::respondErrorValidation($validate->errors()->first());
            }
            if(isset($request->receipt_image))
            {
                if(count($request->receipt_image)==0){
                    if($lang=='en')
                       return Response::respondErrorValidation('Receipt Image is Required');
                    else{
                        return Response::respondErrorValidation('صورة الوصل اجبارية');
                    }
                }
            }

            try {
                DB::beginTransaction();
                $donor = Donor::find($request->donor_id);
                //Wallet::charge($request->amount, $donor->wallet_id);
                $wallet=Wallet::where('id',$donor->wallet_id)->first();
                $wallet->amount= $wallet->amount+$request->amount;
                $wallet->last_charge_amount = $request->amount;
                $wallet->charge_count= $wallet->charge_count+1;
                $wallet->last_charge_date = Carbon::now();
                 $wallet->update();


                $this->addMedias($request->receipt_image,$donor , 'receipt_image' );
                DB::commit();
                return Response::respondSuccess($donor);

            }
            catch (Exception $e) {
                DB::rollBack();
                return Response::respondError($e);
            }
        }
        else
        return Response::respondErrorAuthorize(__('site.unauthenticate',[],$lang));
    
    }

    
}