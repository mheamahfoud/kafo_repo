<?php

namespace App\Http\Controllers\Api\V1\Mobile\Notifations;
use App\Http\Responses\Response;

use Illuminate\Http\Request;
use Barryvdh\Debugbar\Facade as Debugbar;
use App\Http\Controllers\Controller;
use App\Http\Resources\NotificationsResources;
use App\Models\NotificationModel;
use Notification;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Config;
use Lang;

class NotificationController extends Controller
{
    public function getNotificationsCount(Request $request)
    {
        $lang = $request->header('lang');
        $count = NotificationModel::whereReceiverId(Auth::guard('api')->user()->id)
            ->whereNull('readed_at')
            ->count();
         return Response::respondSuccess($count);
        // return response()->json(['count' => $count]);
    }

    /**
     * get Notifications Content
     *
     * @response  {
     *   "data": [
     *     {
     *       "id": 3344,
     *       "created_ago": "3 months ago",
     *       "title": "Update Task",
     *       "description": "You have new Assgin!",
     *       "type": "Task",
     *       "readed_at": "2021-02-15 08:05:38",
     *       "receiver_id": 8,
     *       "receiver": "Ghofran Jabri",
     *       "sender": "Orwah Habib"
     *     }
     *   ]
     * }
     *
     */

    public function getNotificationsContent(Request $request)
    {

        $lang = $request->header('lang');
      
        $notification = NotificationModel::with('receiver', 'sender')
            ->whereReceiverId(Auth::guard('api')->user()->id)
            ->take(25)
            ->get();

            NotificationModel::whereReceiverId(Auth::guard('api')->user()->id)
            ->whereNull('readed_at')
            ->update(['readed_at' => Carbon::now()->toDateTimeString()]);

            return  NotificationsResources::collection($notification);
      
    
}

    /**
     * set Fcm Token
     *
     * @queryParam token required string
     *
     * @response  {
     *   "status": "success"
     * }
     *
     */


    public function setFcmToken(Request $request)
    {
            User::find(Auth::guard('api')->user()->id)->update([
                'fcm_token' => $request->token,
            ]);
            return Response::respondSuccess('success');
    }
}
